import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  AlertTriangle, 
  Zap, 
  CheckCircle, 
  Calendar, 
  Activity, 
  Sparkles, 
  Clock, 
  TrendingUp, 
  ArrowRight,
  ShieldAlert,
  Sliders,
  HelpCircle
} from "lucide-react";
import { Task, CalendarEvent, Habit, ScheduleAnalysis } from "../types";

interface DashboardProps {
  tasks: Task[];
  calendarEvents: CalendarEvent[];
  habits: Habit[];
  analysis: ScheduleAnalysis | null;
  analyzing: boolean;
  onRunAnalysis: () => void;
  onTriggerRescueMode: () => void;
  onSelectTab: (tab: string) => void;
}

export default function Dashboard({
  tasks,
  calendarEvents,
  habits,
  analysis,
  analyzing,
  onRunAnalysis,
  onTriggerRescueMode,
  onSelectTab
}: DashboardProps) {
  
  const incompleteTasks = tasks.filter(t => !t.completed);
  const highPriorityCount = incompleteTasks.filter(t => t.urgency === "high" || t.importance === "high").length;
  
  // Calculate a visual risk score color
  const getRiskColor = (score: number) => {
    if (score < 30) return { stroke: "stroke-emerald-500", text: "text-emerald-500", bg: "bg-emerald-50 text-emerald-700", border: "border-emerald-100" };
    if (score < 65) return { stroke: "stroke-amber-500", text: "text-amber-600", bg: "bg-amber-50 text-amber-700", border: "border-amber-100" };
    return { stroke: "stroke-rose-500", text: "text-rose-600", bg: "bg-rose-50 text-rose-700", border: "border-rose-100" };
  };

  const riskInfo = getRiskColor(analysis?.riskScore ?? 15);
  const activeStreak = habits.length > 0 ? Math.max(...habits.map(h => h.streak)) : 0;

  return (
    <div className="space-y-8">
      {/* Upper Grid: AI Status & Critical Rescue Trigger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Card 1: AI Deadline Risk Analyzer */}
        <div className="glass-panel p-6 rounded-2xl flex flex-col items-center text-center relative overflow-hidden transition-all duration-300 hover:shadow-md">
          <div className="absolute top-4 right-4 text-xs font-mono bg-gray-100 px-2.5 py-1 rounded-full text-gray-500 flex items-center gap-1.5">
            <Activity className="w-3 h-3 animate-pulse text-indigo-500" />
            AI Live
          </div>
          
          <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider font-display mb-6">
            Deadline Miss Risk
          </h2>

          <div className="relative w-44 h-44 flex items-center justify-center mb-4">
            {/* Background Circle */}
            <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                className="stroke-gray-100 fill-none"
                strokeWidth="8"
              />
              {/* Foreground Animated Gauge */}
              <motion.circle
                cx="50"
                cy="50"
                r="40"
                className={`fill-none ${riskInfo.stroke}`}
                strokeWidth="8"
                strokeDasharray="251.2"
                initial={{ strokeDashoffset: 251.2 }}
                animate={{ 
                  strokeDashoffset: 251.2 - (251.2 * (analysis?.riskScore ?? 15)) / 100 
                }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
            </svg>
            
            <div className="text-center z-10">
              <span className="text-5xl font-bold font-display tracking-tight text-gray-900">
                {analysis?.riskScore ?? 15}%
              </span>
              <p className="text-xs font-medium text-gray-400 mt-1 uppercase tracking-wide">
                Risk Level
              </p>
            </div>
          </div>

          <div className={`px-4 py-2 rounded-full text-xs font-medium border ${riskInfo.bg} ${riskInfo.border} mb-4 max-w-xs text-center line-clamp-2`}>
            {analyzing ? "AI is reviewing schedule..." : (analysis?.riskAnalysis || "Your schedule is stable and well-balanced.")}
          </div>

          <button
            onClick={onRunAnalysis}
            disabled={analyzing}
            className="w-full mt-auto py-2.5 px-4 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            {analyzing ? "Analyzing Plan..." : "Re-Optimize with AI"}
          </button>
        </div>

        {/* Card 2: Next Best Action & Rescue Mode Trigger */}
        <div className="glass-panel p-6 rounded-2xl lg:col-span-2 flex flex-col justify-between relative overflow-hidden transition-all duration-300 hover:shadow-md">
          {/* Decorative background pulse */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-rose-400/10 rounded-full blur-3xl pointer-events-none"></div>
          
          <div>
            <div className="flex justify-between items-start mb-6">
              <div>
                <span className="text-xs font-mono font-bold text-rose-500 uppercase tracking-widest flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 animate-pulse" />
                  Emergency Operations
                </span>
                <h2 className="text-2xl font-bold font-display tracking-tight text-gray-900 mt-1">
                  Commitment Rescue Desk
                </h2>
              </div>
              <span className="text-xs font-mono bg-rose-50 text-rose-600 border border-rose-100 px-3 py-1 rounded-full font-semibold">
                Rescue Mode Enabled
              </span>
            </div>

            <p className="text-gray-600 text-sm leading-relaxed mb-6 max-w-xl">
              Are you slipping behind schedule? Don't panic. Trigger **Rescue Mode** to allow Planner Pro's AI to temporarily postpone non-critical tasks, draft client extension emails, and organize a rapid-execution recovery checklist.
            </p>

            {/* Next Best Action Banner */}
            <div className="bg-indigo-50 border border-indigo-100/80 rounded-xl p-4 flex items-start gap-4 mb-6">
              <div className="p-2 bg-indigo-500 text-white rounded-lg mt-0.5 shadow-sm">
                <Zap className="w-4 h-4 text-yellow-300 fill-yellow-300" />
              </div>
              <div>
                <h3 className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wider">
                  Recommended Next Best Action
                </h3>
                <p className="text-gray-900 font-medium text-sm mt-0.5">
                  {analyzing ? "Calculating..." : (analysis?.nextBestAction || "Complete your Q3 Financial Report priority subtasks.")}
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={onTriggerRescueMode}
              className="flex-1 py-3 px-5 bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 shadow-sm transition-all hover:shadow hover:shadow-rose-100 active:scale-[0.98] cursor-pointer"
            >
              <AlertTriangle className="w-4.5 h-4.5 animate-bounce text-white" />
              Trigger AI Rescue Mode
            </button>
            <button
              onClick={() => onSelectTab("schedule")}
              className="py-3 px-5 border border-gray-200 hover:bg-gray-50 text-gray-700 font-medium rounded-xl text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              View Daily Timeline
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Stats Counter Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-panel p-5 rounded-xl transition-all duration-300 hover:-translate-y-1">
          <div className="flex justify-between items-start">
            <span className="text-xs font-mono font-medium text-gray-400 uppercase tracking-wide">Pending Tasks</span>
            <CheckCircle className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-3xl font-bold font-display mt-2 text-gray-900">{incompleteTasks.length}</p>
          <p className="text-xs text-gray-500 mt-1">{highPriorityCount} marked high-priority</p>
        </div>

        <div className="glass-panel p-5 rounded-xl transition-all duration-300 hover:-translate-y-1">
          <div className="flex justify-between items-start">
            <span className="text-xs font-mono font-medium text-gray-400 uppercase tracking-wide">Appointments</span>
            <Calendar className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-3xl font-bold font-display mt-2 text-gray-900">{calendarEvents.length}</p>
          <p className="text-xs text-gray-500 mt-1">Fixed schedule anchors</p>
        </div>

        <div className="glass-panel p-5 rounded-xl transition-all duration-300 hover:-translate-y-1">
          <div className="flex justify-between items-start">
            <span className="text-xs font-mono font-medium text-gray-400 uppercase tracking-wide">Best Habit Streak</span>
            <TrendingUp className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-3xl font-bold font-display mt-2 text-gray-900">{activeStreak} Days</p>
          <p className="text-xs text-gray-500 mt-1">Habits build consistency</p>
        </div>

        <div className="glass-panel p-5 rounded-xl transition-all duration-300 hover:-translate-y-1">
          <div className="flex justify-between items-start">
            <span className="text-xs font-mono font-medium text-gray-400 uppercase tracking-wide">Daily Focus Hours</span>
            <Clock className="w-4 h-4 text-teal-500" />
          </div>
          <p className="text-3xl font-bold font-display mt-2 text-gray-900">9 hrs</p>
          <p className="text-xs text-gray-500 mt-1">9:00 AM - 6:00 PM</p>
        </div>
      </div>

      {/* AI Tailored Recommendations Board */}
      <div className="glass-panel p-6 rounded-2xl relative overflow-hidden">
        <div className="flex items-center gap-2.5 mb-6">
          <div className="p-2 bg-amber-50 rounded-lg border border-amber-100">
            <Sparkles className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <h2 className="text-lg font-bold font-display tracking-tight text-gray-900">
              AI Tailored Productivity Insights
            </h2>
            <p className="text-xs text-gray-500 font-medium">Derived from workload, focus peak profiles, and commitments</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {analyzing ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse space-y-3 p-4 bg-gray-50 rounded-xl">
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
                <div className="h-3 bg-gray-200 rounded w-5/6"></div>
              </div>
            ))
          ) : (
            (analysis?.recommendations || [
              "Schedule high-effort financial tasks before your 10:00 AM engineering sync while cognitive energy is high.",
              "Prepare your portfolio wireframe updates ahead of the 1:30 PM review to keep Sarah's client meeting focused.",
              "Defer low-priority dentist follow-ups to Friday morning to secure clear deep-work blocks during mid-week."
            ]).map((rec, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="p-5 rounded-xl border border-gray-100 bg-gray-50/50 flex flex-col justify-between"
              >
                <div>
                  <span className="text-xs font-mono font-bold text-gray-400">INSIGHT {i + 1}</span>
                  <p className="text-gray-700 text-sm font-medium leading-relaxed mt-2.5">{rec}</p>
                </div>
                <div className="flex items-center gap-1 text-xs text-indigo-600 font-semibold mt-4">
                  <span>Smart Recommendation</span>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
