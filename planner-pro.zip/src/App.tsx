import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  AlertTriangle, 
  CheckCircle, 
  Circle, 
  Calendar, 
  Activity, 
  Clock, 
  TrendingUp, 
  ArrowRight, 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Mic, 
  Send, 
  Sliders, 
  Mail, 
  Copy, 
  Check, 
  ExternalLink,
  ChevronRight,
  User,
  Coffee,
  HelpCircle,
  FileText,
  Briefcase
} from "lucide-react";
import { Task, CalendarEvent, Habit, WorkSettings, ScheduleAnalysis, RescuePlan, ExtensionEmail } from "./types";
import { initialTasks, initialCalendarEvents, initialHabits, initialWorkSettings } from "./data/initialData";
import Dashboard from "./components/Dashboard";

export default function App() {
  // Tab Navigation
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // App States with localStorage Persistence
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem("planner_pro_tasks");
    return saved ? JSON.parse(saved) : initialTasks;
  });
  
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem("planner_pro_calendar");
    return saved ? JSON.parse(saved) : initialCalendarEvents;
  });

  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem("planner_pro_habits");
    return saved ? JSON.parse(saved) : initialHabits;
  });

  const [workSettings, setWorkSettings] = useState<WorkSettings>(() => {
    const saved = localStorage.getItem("planner_pro_settings");
    return saved ? JSON.parse(saved) : initialWorkSettings;
  });

  const [currentTime, setCurrentTime] = useState<string>("2026-06-30T09:00:00");
  
  // AI Results
  const [analysis, setAnalysis] = useState<ScheduleAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [rescuePlan, setRescuePlan] = useState<RescuePlan | null>(null);
  const [rescuing, setRescuing] = useState<boolean>(false);
  
  // Interactive UI States
  const [voiceText, setVoiceText] = useState<string>("");
  const [parsingVoice, setParsingVoice] = useState<boolean>(false);
  const [showNewTaskModal, setShowNewTaskModal] = useState<boolean>(false);
  const [showGoalModal, setShowGoalModal] = useState<boolean>(false);
  const [copiedEmailIndex, setCopiedEmailIndex] = useState<number | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);

  // New Task Form State
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    urgency: "medium" as "high" | "medium" | "low",
    importance: "medium" as "high" | "medium" | "low",
    durationMinutes: 60,
    dueDate: "2026-06-30",
    dependencyId: ""
  });

  // Goal Breakdown State
  const [goalForm, setGoalForm] = useState({
    title: "",
    description: "",
    totalHours: 4
  });
  const [breakingGoal, setBreakingGoal] = useState<boolean>(false);
  const [goalResultSubtasks, setGoalResultSubtasks] = useState<any[]>([]);

  // Email Draft Workspace State
  const [activeDraft, setActiveDraft] = useState<ExtensionEmail | null>(null);
  const [showEmailWorkspace, setShowEmailWorkspace] = useState<boolean>(false);
  const [emailTone, setEmailTone] = useState<string>("professional");
  const [emailLoading, setEmailLoading] = useState<boolean>(false);

  // Sync state to local storage on changes
  useEffect(() => {
    localStorage.setItem("planner_pro_tasks", JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("planner_pro_calendar", JSON.stringify(calendarEvents));
  }, [calendarEvents]);

  useEffect(() => {
    localStorage.setItem("planner_pro_habits", JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem("planner_pro_settings", JSON.stringify(workSettings));
  }, [workSettings]);

  // Initial analysis fetch
  useEffect(() => {
    runScheduleAnalysis();
  }, []);

  const runScheduleAnalysis = async () => {
    setAnalyzing(true);
    setApiError(null);
    try {
      const response = await fetch("/api/gemini/analyze-schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tasks,
          calendarEvents,
          habits,
          workSettings,
          currentTime
        })
      });
      if (!response.ok) throw new Error("Analysis failed");
      const data = await response.json();
      setAnalysis(data);
    } catch (err: any) {
      console.error(err);
      setApiError("Using offline schedule fallback module. Make sure GEMINI_API_KEY is configured in your secrets.");
      // Apply mock local fallback if server fails
      const fallback = getOfflineAnalysis();
      setAnalysis(fallback);
    } finally {
      setAnalyzing(false);
    }
  };

  const triggerRescueMode = async () => {
    setRescuing(true);
    setApiError(null);
    try {
      const response = await fetch("/api/gemini/rescue-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tasks,
          calendarEvents,
          currentTime
        })
      });
      if (!response.ok) throw new Error("Rescue trigger failed");
      const data = await response.json();
      setRescuePlan(data);
      // Automatically redirect to Rescue tab
      setActiveTab("rescue");
    } catch (err: any) {
      console.error(err);
      setApiError("Fallback Rescue Plan loaded. Enter a valid Gemini API Key to unlock real-time tactical advice.");
      setRescuePlan(getOfflineRescuePlan());
      setActiveTab("rescue");
    } finally {
      setRescuing(false);
    }
  };

  const handleVoiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!voiceText.trim()) return;
    setParsingVoice(true);
    setApiError(null);
    try {
      const response = await fetch("/api/gemini/voice-parse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript: voiceText })
      });
      if (!response.ok) throw new Error("Voice parse failed");
      const data = await response.json();
      if (data.tasks && data.tasks.length > 0) {
        const parsedTasks: Task[] = data.tasks.map((t: any, index: number) => ({
          id: `voice-task-${Date.now()}-${index}`,
          title: t.title,
          description: `Automatically created via AI Voice Planning Desk. Due: ${t.dueDate || 'Today'}`,
          urgency: t.urgency || "medium",
          importance: t.importance || "medium",
          durationMinutes: t.durationMinutes || 45,
          dueDate: t.dueDate || "2026-06-30",
          completed: false,
          subtasks: (t.subtasks || []).map((sub: string, subIdx: number) => ({
            id: `voice-sub-${Date.now()}-${index}-${subIdx}`,
            title: sub,
            completed: false
          }))
        }));
        setTasks(prev => [...parsedTasks, ...prev]);
        setVoiceText("");
        // Notify or alert
        runScheduleAnalysis();
      }
    } catch (err) {
      console.error(err);
      // Mock parsing as fallback
      const offlineTask: Task = {
        id: `voice-task-fallback-${Date.now()}`,
        title: voiceText,
        urgency: "medium",
        importance: "high",
        durationMinutes: 45,
        dueDate: "2026-06-30",
        completed: false,
        subtasks: []
      };
      setTasks(prev => [offlineTask, ...prev]);
      setVoiceText("");
      runScheduleAnalysis();
    } finally {
      setParsingVoice(false);
    }
  };

  const handleBreakDownGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalForm.title.trim()) return;
    setBreakingGoal(true);
    setApiError(null);
    try {
      const response = await fetch("/api/gemini/break-down-goal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(goalForm)
      });
      if (!response.ok) throw new Error("Goal break down failed");
      const data = await response.json();
      setGoalResultSubtasks(data.subtasks || []);
    } catch (err) {
      console.error(err);
      setGoalResultSubtasks([
        { title: "Define scope & objective statements", durationMinutes: 45, difficulty: "easy" },
        { title: "Review past reference templates", durationMinutes: 60, difficulty: "easy" },
        { title: "Implement key core structures", durationMinutes: 120, difficulty: "hard" },
        { title: "Review dependencies and finalize details", durationMinutes: 45, difficulty: "medium" }
      ]);
    } finally {
      setBreakingGoal(false);
    }
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title.trim()) return;
    const task: Task = {
      id: `task-${Date.now()}`,
      title: newTask.title,
      description: newTask.description,
      urgency: newTask.urgency,
      importance: newTask.importance,
      durationMinutes: Number(newTask.durationMinutes),
      dueDate: newTask.dueDate,
      completed: false,
      subtasks: [],
      dependencyId: newTask.dependencyId || undefined
    };
    setTasks(prev => [task, ...prev]);
    setShowNewTaskModal(false);
    setNewTask({
      title: "",
      description: "",
      urgency: "medium",
      importance: "medium",
      durationMinutes: 60,
      dueDate: "2026-06-30",
      dependencyId: ""
    });
    runScheduleAnalysis();
  };

  const handleAddGoalTasks = () => {
    const tasksToAdd: Task[] = goalResultSubtasks.map((sub, i) => ({
      id: `goal-sub-${Date.now()}-${i}`,
      title: `${goalForm.title}: ${sub.title}`,
      description: `Step ${i + 1} of goal breakdown: ${goalForm.title}. Difficulty: ${sub.difficulty}`,
      urgency: "medium",
      importance: "medium",
      durationMinutes: sub.durationMinutes || 60,
      dueDate: "2026-06-30",
      completed: false,
      subtasks: []
    }));
    setTasks(prev => [...tasksToAdd, ...prev]);
    setShowGoalModal(false);
    setGoalForm({ title: "", description: "", totalHours: 4 });
    setGoalResultSubtasks([]);
    runScheduleAnalysis();
  };

  const toggleTaskCompleted = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
    setTimeout(() => runScheduleAnalysis(), 100);
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    setTimeout(() => runScheduleAnalysis(), 100);
  };

  const handleAddSubtask = (taskId: string, subtaskTitle: string) => {
    if (!subtaskTitle.trim()) return;
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          subtasks: [...t.subtasks, { id: `sub-${Date.now()}`, title: subtaskTitle, completed: false }]
        };
      }
      return t;
    }));
  };

  const toggleSubtaskCompleted = (taskId: string, subtaskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          subtasks: t.subtasks.map(s => s.id === subtaskId ? { ...s, completed: !s.completed } : s)
        };
      }
      return t;
    }));
  };

  const handleToggleHabit = (id: string) => {
    setHabits(prev => prev.map(h => {
      if (h.id === id) {
        const completed = !h.completedToday;
        return {
          ...h,
          completedToday: completed,
          streak: completed ? h.streak + 1 : Math.max(0, h.streak - 1)
        };
      }
      return h;
    }));
  };

  const handleCustomTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTime(e.target.value);
  };

  const handleDraftEmailRequest = async (email: ExtensionEmail) => {
    setEmailLoading(true);
    setActiveDraft(email);
    setShowEmailWorkspace(true);
    try {
      const response = await fetch("/api/gemini/draft-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taskTitle: email.subject.replace("Rescheduling Request: Extension for ", ""),
          dueDate: "2026-06-30",
          reason: email.reason,
          recipientName: email.recipient,
          tone: emailTone
        })
      });
      if (response.ok) {
        const data = await response.json();
        setActiveDraft(prev => prev ? { ...prev, subject: data.subject, body: data.body } : null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setEmailLoading(false);
    }
  };

  const handleCopyEmail = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedEmailIndex(index);
    setTimeout(() => setCopiedEmailIndex(null), 2000);
  };

  // Safe offline local fallbacks
  const getOfflineAnalysis = (): ScheduleAnalysis => {
    return {
      riskScore: 35,
      riskAnalysis: "Active Local Fallback. Schedule contains 3 upcoming deadlines with no critical overlaps.",
      nextBestAction: tasks.find(t => !t.completed)?.title || "Review project targets",
      recommendedSequence: tasks.map(t => t.id),
      scheduleSlots: [
        { time: "09:00 AM", type: "task", label: "Focus Work: Q3 Report Preparation", durationMinutes: 120 },
        { time: "11:30 AM", type: "habit", label: "Drink 1L Water & Stretch", durationMinutes: 15 },
        { time: "01:30 PM", type: "commitment", label: "Sarah Client Wireframe Check-in", durationMinutes: 45 },
        { time: "03:00 PM", type: "task", label: "Review App Spec Documents", durationMinutes: 90 }
      ],
      recommendations: [
        "Prioritize the high-urgency Q3 Financial Report before external meetings start.",
        "Take a brief screen break after completing high effort blocks.",
        "Use focus hours to block out Slack notifications entirely."
      ]
    };
  };

  const getOfflineRescuePlan = (): RescuePlan => {
    return {
      recoverySteps: [
        "Isolate focus: disable desktop notifications for the next 2 hours.",
        "Take a 5-minute deep breathing sequence to lower stress hormones.",
        "Postpone standard dentistry & app roadmaps to tomorrow.",
        "Focus purely on compiling June department expense sheets."
      ],
      deferredTasks: ["task-3", "task-5"],
      extensionEmails: [
        {
          subject: "Extension request for Nova Core deliverables",
          recipient: "Sarah (Product Partner)",
          reason: "critical system downtime and database schema refactoring",
          body: "Hi Sarah,\n\nI hope you're doing well. I am working diligently on finalizing our Mobile App Design Specifications.\n\nDue to unexpected bottlenecks with the data schemas, I would like to request an extension of 24 hours to ensure our mockups are absolutely flawless.\n\nThank you,\nAlex"
        }
      ],
      calmingQuote: "Do not stress over what is delayed. Focus fully on the task immediately in front of you."
    };
  };

  // Active Rescue Steps remaining count
  const completedRescueSteps = 0; // State can track if wanted

  return (
    <div className="w-full min-h-screen bg-slate-50 flex flex-row text-slate-900 font-sans antialiased overflow-hidden">
      
      {/* 1. Left Sidebar (Sleek Theme Layout) */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col shrink-0 justify-between h-screen overflow-y-auto">
        <div>
          <div className="p-6 flex items-center gap-3">
            <div className="w-9 h-9 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-indigo-100">
              <Sparkles className="w-5 h-5 text-yellow-300 fill-yellow-300" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight block text-slate-900 font-display">Planner Pro</span>
              <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider font-mono">Last-Minute Life Saver</span>
            </div>
          </div>

          <nav className="px-4 space-y-1 mt-2">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === "dashboard"
                  ? "bg-indigo-50 text-indigo-700 shadow-sm"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <span className="text-lg">⊞</span> Dashboard
            </button>
            <button
              onClick={() => setActiveTab("schedule")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === "schedule"
                  ? "bg-indigo-50 text-indigo-700 shadow-sm"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <span className="text-lg">📅</span> Schedule & Plan
            </button>
            <button
              onClick={() => setActiveTab("goals")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === "goals"
                  ? "bg-indigo-50 text-indigo-700 shadow-sm"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <span className="text-lg">🎯</span> Goal Breaker
            </button>
            <button
              onClick={() => setActiveTab("rescue")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer relative ${
                activeTab === "rescue"
                  ? "bg-indigo-50 text-indigo-700 shadow-sm"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <span className="text-lg">⚡</span> Rescue Workspace
              {rescuePlan && (
                <span className="absolute right-3 top-3.5 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping"></span>
              )}
            </button>
            <button
              onClick={() => setActiveTab("settings")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer ${
                activeTab === "settings"
                  ? "bg-indigo-50 text-indigo-700 shadow-sm"
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              <span className="text-lg">⚙️</span> Settings
            </button>
          </nav>
        </div>

        {/* Sidebar Footer System Status */}
        <div className="p-4 mb-2">
          <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3 shadow-xl">
            <div className="flex items-center justify-between">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">System Status</p>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-400 animate-pulse" />
              <p className="text-sm font-semibold">AI Assistant Active</p>
            </div>
            <p className="text-[11px] leading-relaxed opacity-70">
              Actively calculating workload weight, optimizing focus sequences, and monitoring risks.
            </p>
          </div>
        </div>
      </aside>

      {/* 2. Main Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        
        {/* Header (Sleek Theme) */}
        <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0 z-10">
          <div>
            <h1 className="text-xl font-bold text-slate-800 font-display">Good morning, Alex</h1>
            <p className="text-xs text-slate-500">
              {new Date(currentTime).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          
          <div className="flex items-center gap-5">
            {/* API Status Flag */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="font-medium">Cloud API Connected</span>
            </div>

            {/* Quick simulated Voice Input Action Header */}
            <form onSubmit={handleVoiceSubmit} className="relative hidden lg:flex items-center">
              <input
                type="text"
                placeholder="Talk to Planner Pro... (e.g. 'Add high priority bug review today')"
                value={voiceText}
                onChange={(e) => setVoiceText(e.target.value)}
                className="w-80 pl-10 pr-10 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
              <Mic className="absolute left-3 w-4 h-4 text-indigo-500" />
              <button 
                type="submit" 
                disabled={parsingVoice} 
                className="absolute right-2 p-1 text-slate-400 hover:text-indigo-600 transition-colors"
              >
                {parsingVoice ? (
                  <span className="w-3.5 h-3.5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin block"></span>
                ) : (
                  <Send className="w-3.5 h-3.5" />
                )}
              </button>
            </form>

            <div className="relative">
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-orange-500 border-2 border-white rounded-full"></span>
              <button className="w-10 h-10 rounded-xl border border-slate-200 flex items-center justify-center text-slate-600 hover:bg-slate-50 transition-colors">
                🔔
              </button>
            </div>
            
            <div className="w-10 h-10 rounded-xl bg-indigo-100 border border-indigo-200 flex items-center justify-center text-indigo-700 font-bold text-sm">
              AX
            </div>
          </div>
        </header>

        {/* API Error Alert Banner */}
        {apiError && (
          <div className="bg-amber-50 border-b border-amber-200 px-8 py-2 text-xs text-amber-700 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="w-4.5 h-4.5 text-amber-500" />
              {apiError}
            </span>
            <button onClick={() => setApiError(null)} className="font-semibold underline hover:text-amber-950">Dismiss</button>
          </div>
        )}

        {/* Scrollable Content Workspace */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          
          <AnimatePresence mode="wait">
            
            {/* TAB 1: DASHBOARD VIEW */}
            {activeTab === "dashboard" && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="space-y-8"
              >
                {/* 1. Rescue Mode Banner if deadlines are critical */}
                {analysis && analysis.riskScore >= 40 && (
                  <div className="bg-gradient-to-r from-orange-500 to-rose-500 rounded-2xl p-6 text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg shadow-orange-100 h-auto md:h-28">
                    <div className="flex items-center gap-5">
                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl shadow-inner">
                        ⚡
                      </div>
                      <div>
                        <h3 className="font-bold text-lg font-display">Rescue Mode Recommended</h3>
                        <p className="text-white/80 text-sm mt-0.5">
                          High workload detected with {tasks.filter(t => !t.completed && t.urgency === 'high').length} pending high-priority deadlines. Adjust timelines?
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <button 
                        onClick={triggerRescueMode}
                        className="px-5 py-2 bg-white text-orange-600 rounded-xl font-bold text-sm shadow-sm hover:bg-orange-50 active:scale-95 transition-all cursor-pointer"
                      >
                        Generate Recovery Plan
                      </button>
                      <button 
                        onClick={() => runScheduleAnalysis()}
                        className="px-5 py-2 bg-white/20 text-white rounded-xl font-bold text-sm backdrop-blur-sm hover:bg-white/30 transition-all cursor-pointer"
                      >
                        Ignore
                      </button>
                    </div>
                  </div>
                )}

                {/* Main Dashboard Panel */}
                <Dashboard 
                  tasks={tasks}
                  calendarEvents={calendarEvents}
                  habits={habits}
                  analysis={analysis}
                  analyzing={analyzing}
                  onRunAnalysis={runScheduleAnalysis}
                  onTriggerRescueMode={triggerRescueMode}
                  onSelectTab={setActiveTab}
                />

                {/* Split layout: Quick Planner Timeline & Habit Tracker */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left Schedule Timeline */}
                  <div className="glass-panel p-6 rounded-2xl lg:col-span-2">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="font-bold text-lg font-display text-slate-900">Today's Optimized Schedule</h3>
                        <p className="text-xs text-slate-500">Chronological list of fixed and variable blocks</p>
                      </div>
                      <button 
                        onClick={() => setActiveTab("schedule")}
                        className="text-indigo-600 font-bold text-xs flex items-center gap-1 hover:underline"
                      >
                        Manage Schedule <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="space-y-4">
                      {analysis?.scheduleSlots && analysis.scheduleSlots.length > 0 ? (
                        analysis.scheduleSlots.map((slot, index) => (
                          <div key={index} className="flex gap-4 items-start group">
                            <span className="w-16 text-xs font-mono font-bold text-slate-400 pt-1.5 shrink-0">
                              {slot.time}
                            </span>
                            <div className={`flex-1 border-l-4 p-4 rounded-r-xl transition-all hover:bg-slate-50 ${
                              slot.type === 'commitment' 
                                ? 'bg-rose-50/50 border-rose-400' 
                                : slot.type === 'task' 
                                ? 'bg-indigo-50/50 border-indigo-500' 
                                : slot.type === 'habit'
                                ? 'bg-amber-50/50 border-amber-400'
                                : 'bg-slate-50 border-slate-300'
                            }`}>
                              <div className="flex justify-between items-start">
                                <h4 className={`font-bold text-sm ${
                                  slot.type === 'commitment' ? 'text-rose-950' : slot.type === 'task' ? 'text-indigo-950' : 'text-slate-900'
                                }`}>
                                  {slot.label}
                                </h4>
                                <span className={`text-[10px] px-2 py-0.5 rounded border uppercase font-bold tracking-tight shrink-0 ${
                                  slot.type === 'commitment'
                                    ? 'bg-rose-100 text-rose-700 border-rose-200'
                                    : slot.type === 'task'
                                    ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                                    : 'bg-slate-100 text-slate-600 border-slate-200'
                                }`}>
                                  {slot.type}
                                </span>
                              </div>
                              <p className="text-xs text-slate-500 mt-1">
                                Duration: {slot.durationMinutes} minutes • {slot.type === 'commitment' ? 'External meeting' : 'Recommended focus slot'}
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="py-8 text-center text-slate-400 text-sm">
                          No timeline calculated yet. Click "Re-Optimize with AI" to generate one.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Right Habits checklist & Quick Stats */}
                  <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-6">
                        <Activity className="w-4 h-4 text-emerald-500" />
                        <h3 className="font-bold text-lg font-display text-slate-900">Habit Anchor Desk</h3>
                      </div>
                      
                      <div className="space-y-3.5">
                        {habits.map((habit) => (
                          <div 
                            key={habit.id}
                            className="p-3.5 border border-slate-100 bg-slate-50/50 hover:bg-slate-50 rounded-xl flex items-center justify-between transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <button 
                                onClick={() => handleToggleHabit(habit.id)}
                                className="text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer"
                              >
                                {habit.completedToday ? (
                                  <CheckCircle className="w-5 h-5 text-indigo-600 fill-indigo-100" />
                                ) : (
                                  <Circle className="w-5 h-5 text-slate-300" />
                                )}
                              </button>
                              <div>
                                <h4 className={`text-xs font-semibold ${habit.completedToday ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                                  {habit.title}
                                </h4>
                                <p className="text-[10px] text-slate-400 font-medium">Streak: {habit.streak} days • {habit.frequency}</p>
                              </div>
                            </div>
                            <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-2 py-0.5 rounded">
                              +{habit.streak * 5} pts
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-5 mt-6">
                      <div className="flex justify-between text-xs font-medium text-slate-500 mb-2">
                        <span>Daily Consistency Score</span>
                        <span>80%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full w-[80%] transition-all duration-500"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 2: SCHEDULE & TASK MANAGER VIEW */}
            {activeTab === "schedule" && (
              <motion.div
                key="schedule"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="space-y-8"
              >
                {/* Section Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900 font-display">Schedule & Task Matrix</h2>
                    <p className="text-xs text-slate-500">Organize commitments, track dependencies, and break down tasks</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowNewTaskModal(true)}
                      className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4" /> Add Task
                    </button>
                    <button
                      onClick={() => {
                        setGoalForm({ title: "Nova Core Deliverables", description: "Design pitch slides and backend integration", totalHours: 6 });
                        setShowGoalModal(true);
                      }}
                      className="py-2 px-4 bg-white border border-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 hover:bg-slate-50 transition-all cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-amber-500" /> Break Down Goal
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Task Matrix Column (Left 2 Columns) */}
                  <div className="lg:col-span-2 space-y-4">
                    <div className="glass-panel p-6 rounded-2xl">
                      <div className="flex justify-between items-center mb-6">
                        <h3 className="font-bold text-sm uppercase tracking-wider text-slate-500 font-mono">Tasks Repository</h3>
                        <span className="text-xs font-semibold bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-full">
                          {tasks.filter(t => !t.completed).length} Pending
                        </span>
                      </div>

                      <div className="divide-y divide-slate-100">
                        {tasks.map((task) => (
                          <div key={task.id} className="py-4 first:pt-0 last:pb-0">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex items-start gap-3">
                                <button 
                                  onClick={() => toggleTaskCompleted(task.id)}
                                  className="text-slate-400 hover:text-indigo-600 mt-1 cursor-pointer"
                                >
                                  {task.completed ? (
                                    <CheckCircle className="w-5 h-5 text-indigo-600 fill-indigo-50" />
                                  ) : (
                                    <Circle className="w-5 h-5 text-slate-300" />
                                  )}
                                </button>
                                <div>
                                  <h4 className={`text-sm font-semibold text-slate-900 ${task.completed ? 'line-through text-slate-400' : ''}`}>
                                    {task.title}
                                  </h4>
                                  {task.description && (
                                    <p className="text-xs text-slate-500 mt-1 max-w-lg">{task.description}</p>
                                  )}
                                  
                                  {/* Task Indicators */}
                                  <div className="flex flex-wrap items-center gap-2 mt-2.5">
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                      task.urgency === 'high' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'
                                    }`}>
                                      Urgency: {task.urgency}
                                    </span>
                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                      task.importance === 'high' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-600'
                                    }`}>
                                      Importance: {task.importance}
                                    </span>
                                    <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded flex items-center gap-1">
                                      <Clock className="w-3 h-3" /> {task.durationMinutes} mins
                                    </span>
                                    {task.dependencyId && (
                                      <span className="text-[10px] font-bold text-amber-600 bg-amber-50 border border-amber-100 px-2 py-0.5 rounded flex items-center gap-1">
                                        ⛓️ Depends on: {tasks.find(t => t.id === task.dependencyId)?.title || "other task"}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>

                              <button 
                                onClick={() => deleteTask(task.id)}
                                className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            {/* Nesting Subtasks for deep goal alignment */}
                            {task.subtasks.length > 0 && (
                              <div className="ml-8 mt-3 pl-4 border-l border-slate-150 space-y-2">
                                {task.subtasks.map((sub) => (
                                  <div key={sub.id} className="flex items-center gap-2 text-xs">
                                    <button 
                                      onClick={() => toggleSubtaskCompleted(task.id, sub.id)}
                                      className="text-slate-400 hover:text-indigo-600 cursor-pointer"
                                    >
                                      {sub.completed ? (
                                        <Check className="w-4 h-4 text-emerald-500 font-bold" />
                                      ) : (
                                        <div className="w-3.5 h-3.5 rounded border border-slate-300"></div>
                                      )}
                                    </button>
                                    <span className={sub.completed ? "line-through text-slate-400 font-medium" : "text-slate-700 font-medium"}>
                                      {sub.title}
                                    </span>
                                  </div>
                                ))}
                              </div>
                            )}

                            {/* Add subtask mini input */}
                            <div className="ml-8 mt-3 pl-4 flex items-center gap-2">
                              <input 
                                type="text"
                                placeholder="Add actionable subtask step..."
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    handleAddSubtask(task.id, e.currentTarget.value);
                                    e.currentTarget.value = '';
                                  }
                                }}
                                className="w-64 bg-slate-50 border border-slate-200 text-xs px-2.5 py-1 rounded-md focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Calendar Anchors (Right Column) */}
                  <div className="space-y-6">
                    <div className="glass-panel p-6 rounded-2xl">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-sm uppercase tracking-wider text-slate-500 font-mono">Calendar Commitments</h3>
                        <Calendar className="w-4 h-4 text-indigo-500" />
                      </div>
                      <p className="text-xs text-slate-500 mb-4">These are unmovable, fixed schedule anchors synced from external accounts.</p>

                      <div className="space-y-3">
                        {calendarEvents.map((evt) => (
                          <div key={evt.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 flex items-start gap-3">
                            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-md shrink-0">
                              {evt.time}
                            </span>
                            <div>
                              <h4 className="text-xs font-bold text-slate-800">{evt.title}</h4>
                              <p className="text-[10px] text-slate-500 mt-0.5">Duration: {evt.duration} mins</p>
                              {evt.description && <p className="text-[10px] text-slate-400 mt-1 italic">{evt.description}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Proactive Traffic & Weather warning card */}
                    <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 border border-indigo-200 rounded-2xl p-6 shadow-sm">
                      <div className="flex items-center gap-2 text-indigo-800 font-bold text-sm mb-3">
                        <Sliders className="w-4.5 h-4.5 text-indigo-600 animate-spin" />
                        <span>AI Traffic Predictive Advice</span>
                      </div>
                      <p className="text-xs text-indigo-950 leading-relaxed">
                        Client meeting Nova Core at <strong>1:30 PM</strong> has heavy traffic on Route 9.
                        <br />
                        <span className="text-rose-600 font-semibold">Delay risk: High (15-20 min delay).</span>
                        <br />
                        Planner Pro suggests drafting a proactive delay email template now, or leaving 20 minutes earlier.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 3: AI GOAL BREAKER */}
            {activeTab === "goals" && (
              <motion.div
                key="goals"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="space-y-8"
              >
                <div className="max-w-4xl mx-auto space-y-6">
                  <div className="text-center space-y-2">
                    <span className="text-xs font-mono font-bold text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full">
                      Strategic Task Breakdowns
                    </span>
                    <h2 className="text-3xl font-black text-slate-900 font-display">Large Goal decomposer</h2>
                    <p className="text-sm text-slate-500 max-w-lg mx-auto">
                      Have a massive project, study target, or quarterly goal? Enter it below and let the AI instantly divide it into clear, step-by-step sequential subtasks.
                    </p>
                  </div>

                  <div className="glass-panel p-8 rounded-2xl space-y-6">
                    <form onSubmit={handleBreakDownGoal} className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Major Goal / Large Task Title</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., Redesign Nova Core Web App Landing Page"
                          value={goalForm.title}
                          onChange={(e) => setGoalForm({ ...goalForm, title: e.target.value })}
                          className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="md:col-span-2">
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Goal Context / Objectives</label>
                          <input
                            type="text"
                            placeholder="Must match current mobile standards, clear illustration, 3 CTA sections."
                            value={goalForm.description}
                            onChange={(e) => setGoalForm({ ...goalForm, description: e.target.value })}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Available Time Budget (Hours)</label>
                          <input
                            type="number"
                            value={goalForm.totalHours}
                            onChange={(e) => setGoalForm({ ...goalForm, totalHours: Number(e.target.value) })}
                            className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={breakingGoal}
                        className="w-full py-3 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                      >
                        {breakingGoal ? (
                          <>
                            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                            AI is building breakdown structure...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-4.5 h-4.5 text-amber-300" />
                            Analyze & Decompose Goal
                          </>
                        )}
                      </button>
                    </form>

                    {/* Result Board */}
                    {goalResultSubtasks.length > 0 && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="border-t border-slate-100 pt-6 space-y-4"
                      >
                        <h3 className="font-bold text-sm text-slate-800 font-display">Suggested Sequential Task Steps</h3>
                        <div className="space-y-2.5">
                          {goalResultSubtasks.map((sub, i) => (
                            <div key={i} className="flex items-center justify-between p-3.5 bg-indigo-50/40 rounded-xl border border-indigo-100/50">
                              <div className="flex items-center gap-3">
                                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                                  {i + 1}
                                </span>
                                <div>
                                  <h4 className="text-xs font-bold text-slate-800">{sub.title}</h4>
                                  {sub.dependency && (
                                    <p className="text-[10px] text-amber-600 font-semibold">⛓️ Depends on: {sub.dependency}</p>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono uppercase font-bold">
                                  {sub.difficulty}
                                </span>
                                <span className="text-xs font-bold text-slate-700">{sub.durationMinutes} mins</span>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="flex gap-3 pt-2">
                          <button
                            onClick={handleAddGoalTasks}
                            className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-all shadow-sm cursor-pointer"
                          >
                            Add All {goalResultSubtasks.length} Steps to Tasks Matrix
                          </button>
                          <button
                            onClick={() => setGoalResultSubtasks([])}
                            className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-xs transition-all cursor-pointer"
                          >
                            Discard
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 4: SOS EMERGENCY RESCUE WORKSPACE */}
            {activeTab === "rescue" && (
              <motion.div
                key="rescue"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="space-y-8"
              >
                <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden border border-slate-800">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl"></div>
                  
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs font-mono font-bold text-rose-400 uppercase tracking-widest flex items-center gap-1">
                        <ShieldAlert className="w-3.5 h-3.5 animate-pulse" />
                        AI Emergency Recovery active
                      </span>
                      <h2 className="text-3xl font-black font-display mt-2">The Commitment Rescue Hub</h2>
                    </div>
                    <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 px-3.5 py-1.5 rounded-full text-xs font-mono font-bold">
                      Critical State Recovery Enabled
                    </span>
                  </div>

                  {rescuePlan?.calmingQuote && (
                    <p className="text-sm italic text-slate-300 mt-6 pl-4 border-l-2 border-rose-500 py-1">
                      "{rescuePlan.calmingQuote}"
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Recovery steps list */}
                  <div className="glass-panel p-6 rounded-2xl lg:col-span-2 space-y-4">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-bold text-sm uppercase tracking-wider text-slate-500 font-mono">Immediate Tactical Checklist</h3>
                      <span className="text-xs font-bold text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded">High Impact</span>
                    </div>

                    <div className="space-y-3">
                      {(rescuePlan?.recoverySteps || [
                        "Isolate environment & disable instant message indicators (slack, teams, outlook).",
                        "Focus on your highest effort task: Draft Q3 Financial Report.",
                        "Request professional reschedule templates for Low Urgency/Medium priority Nova Core Review.",
                        "Stretch for 5 minutes with deliberate breathing at 12:00 PM."
                      ]).map((step, i) => (
                        <div key={i} className="flex items-start gap-3.5 p-4 bg-slate-50 border border-slate-150 rounded-xl">
                          <span className="w-5 h-5 rounded-full bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center text-xs font-black shrink-0">
                            {i + 1}
                          </span>
                          <span className="text-xs font-semibold text-slate-800 leading-relaxed">{step}</span>
                        </div>
                      ))}
                    </div>

                    {rescuePlan?.deferredTasks && rescuePlan.deferredTasks.length > 0 && (
                      <div className="p-4 bg-amber-50/50 border border-amber-200/60 rounded-xl mt-6">
                        <h4 className="text-xs font-bold text-amber-800 flex items-center gap-1.5 mb-2">
                          <AlertTriangle className="w-4 h-4 text-amber-500" />
                          Recommended Deferral Candidates
                        </h4>
                        <p className="text-xs text-amber-900 leading-relaxed mb-3">
                          AI recommends postponing the following task IDs until tomorrow to reduce fatigue and free up critical focus blocks.
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {rescuePlan.deferredTasks.map(id => {
                            const foundTask = tasks.find(t => t.id === id);
                            return (
                              <span key={id} className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2.5 py-1 rounded-md">
                                {foundTask ? foundTask.title : `Task: ${id}`}
                              </span>
                            );
                          })}
                        </div>
                        <button
                          onClick={() => {
                            // Update due dates to tomorrow
                            setTasks(prev => prev.map(t => {
                              if (rescuePlan.deferredTasks.includes(t.id)) {
                                return { ...t, dueDate: "2026-07-01", description: `${t.description || ''} (Postponed by Rescue Mode recommendation)` };
                              }
                              return t;
                            }));
                            setRescuePlan(prev => prev ? { ...prev, deferredTasks: [] } : null);
                            runScheduleAnalysis();
                          }}
                          className="mt-4 py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs transition-colors shadow-sm cursor-pointer"
                        >
                          Approve Timeline Deferral
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Rescheduling Email Draft Section */}
                  <div className="glass-panel p-6 rounded-2xl flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <Mail className="w-4 h-4 text-rose-500 animate-bounce" />
                        <h3 className="font-bold text-base font-display text-slate-900">Extension Draft Workspace</h3>
                      </div>
                      <p className="text-xs text-slate-500 mb-6">
                        Auto-generated communication templates to request extra time from clients or team managers. Let Gemini draft these for you.
                      </p>

                      <div className="space-y-4">
                        {(rescuePlan?.extensionEmails || [
                          {
                            subject: "Nova Core Deliverables: Extension Request",
                            recipient: "Sarah (Product Lead)",
                            reason: "database architecture setbacks",
                            body: "Hi Sarah, I would like to request a 24-hour extension..."
                          }
                        ]).map((email, idx) => (
                          <div key={idx} className="p-4 bg-slate-50 border border-slate-100 rounded-xl space-y-3">
                            <div className="flex justify-between items-center">
                              <span className="text-[10px] font-bold bg-rose-50 text-rose-600 px-2 py-0.5 rounded">
                                Recipient: {email.recipient}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">Template {idx + 1}</span>
                            </div>
                            <h4 className="text-xs font-bold text-slate-800">{email.subject}</h4>
                            <p className="text-[10px] text-slate-500 line-clamp-3 italic">"{email.body}"</p>
                            
                            <div className="flex gap-2 pt-2">
                              <button
                                onClick={() => handleDraftEmailRequest(email)}
                                className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-[10px] transition-colors cursor-pointer"
                              >
                                Draft with AI
                              </button>
                              <button
                                onClick={() => handleCopyEmail(email.body, idx)}
                                className="px-2.5 py-1.5 border border-slate-200 hover:bg-slate-100 rounded-lg text-[10px] transition-all cursor-pointer flex items-center justify-center"
                              >
                                {copiedEmailIndex === idx ? (
                                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                                )}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-5 mt-6">
                      <span className="text-xs font-bold text-slate-500">Need a custom email template?</span>
                      <button
                        onClick={() => {
                          const demoEmail = {
                            subject: "Rescheduling: Client Pitch sync",
                            recipient: "Sarah Client",
                            reason: "urgent system database migration work",
                            body: "Placeholder"
                          };
                          handleDraftEmailRequest(demoEmail);
                        }}
                        className="w-full mt-2.5 py-2 border border-dashed border-slate-300 hover:border-indigo-500 hover:text-indigo-600 rounded-xl text-xs font-semibold text-slate-600 transition-all cursor-pointer"
                      >
                        Draft Custom Reschedule Request
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* TAB 5: SETTINGS */}
            {activeTab === "settings" && (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.25 }}
                className="max-w-3xl mx-auto space-y-8"
              >
                <div className="glass-panel p-8 rounded-2xl space-y-6">
                  <div>
                    <h3 className="text-lg font-bold font-display text-slate-950">Settings & AI Configurations</h3>
                    <p className="text-xs text-slate-500">Customize focus blocks, natural language variables, and model weights.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Focus Hours Start Time</label>
                      <input
                        type="time"
                        value={workSettings.focusStart}
                        onChange={(e) => setWorkSettings({ ...workSettings, focusStart: e.target.value })}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Focus Hours End Time</label>
                      <input
                        type="time"
                        value={workSettings.focusEnd}
                        onChange={(e) => setWorkSettings({ ...workSettings, focusEnd: e.target.value })}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Productivity Chronotype</label>
                      <select
                        value={workSettings.productivityPattern}
                        onChange={(e) => setWorkSettings({ ...workSettings, productivityPattern: e.target.value as any })}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      >
                        <option value="morning">Morning Larks (08:00 AM - 12:00 PM Peak)</option>
                        <option value="afternoon">Afternoon Warriors (01:00 PM - 05:00 PM Peak)</option>
                        <option value="evening">Night Owls (06:00 PM - 10:00 PM Peak)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Mock Clock Override (Testing)</label>
                      <input
                        type="datetime-local"
                        value={currentTime}
                        onChange={handleCustomTimeChange}
                        className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      />
                      <p className="text-[10px] text-slate-400 mt-1">Simulate alternative hours to evaluate the dynamic schedule risk score.</p>
                    </div>
                  </div>

                  <div className="border-t border-slate-100 pt-6">
                    <h4 className="text-xs font-bold text-slate-800 uppercase mb-3">AI Engine Metadata</h4>
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-150 space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Model Deployment:</span>
                        <span className="font-mono font-semibold text-indigo-600">gemini-3.5-flash</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">API Status:</span>
                        <span className="font-semibold text-emerald-600 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Active (Operational)
                        </span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-500">Iframe Permissions:</span>
                        <span className="font-semibold text-slate-700">Standard Framework Allowed</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      onClick={() => {
                        runScheduleAnalysis();
                        alert("Settings applied! AI optimizer re-triggered.");
                      }}
                      className="py-2.5 px-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      Save Settings & Re-Analyze
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

        </div>
      </div>

      {/* ================= MODAL WINDOWS ================= */}
      
      {/* 1. NEW TASK MODAL */}
      {showNewTaskModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-base font-bold font-display text-slate-900">Add New Task to Matrix</h3>
              <button 
                onClick={() => setShowNewTaskModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Deliver Mobile spec draft"
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Description (Optional)</label>
                <textarea
                  placeholder="List dependencies or design principles..."
                  value={newTask.description}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium h-20 resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Urgency</label>
                  <select
                    value={newTask.urgency}
                    onChange={(e) => setNewTask({ ...newTask, urgency: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Importance</label>
                  <select
                    value={newTask.importance}
                    onChange={(e) => setNewTask({ ...newTask, importance: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Duration (Minutes)</label>
                  <input
                    type="number"
                    value={newTask.durationMinutes}
                    onChange={(e) => setNewTask({ ...newTask, durationMinutes: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Due Date</label>
                  <input
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Preceding Task Dependency (Optional)</label>
                <select
                  value={newTask.dependencyId}
                  onChange={(e) => setNewTask({ ...newTask, dependencyId: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                >
                  <option value="">No preceding dependency</option>
                  {tasks.map(t => (
                    <option key={t.id} value={t.id}>{t.title}</option>
                  ))}
                </select>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowNewTaskModal(false)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-600 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Add to Repository
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* 2. DRAFT WORKSPACE MODAL */}
      {showEmailWorkspace && activeDraft && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold font-display text-slate-900">Email Draft Workspace</h3>
              </div>
              <button 
                onClick={() => setShowEmailWorkspace(false)}
                className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Recipient</label>
                  <input
                    type="text"
                    value={activeDraft.recipient}
                    onChange={(e) => setActiveDraft({ ...activeDraft, recipient: e.target.value })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tone Preference</label>
                  <select
                    value={emailTone}
                    onChange={(e) => {
                      setEmailTone(e.target.value);
                      setTimeout(() => handleDraftEmailRequest(activeDraft), 100);
                    }}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <option value="professional">Professional & Sincere</option>
                    <option value="casual">Casual & Direct</option>
                    <option value="urgent">Urgent & Direct</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Subject</label>
                <input
                  type="text"
                  value={activeDraft.subject}
                  onChange={(e) => setActiveDraft({ ...activeDraft, subject: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Draft Content</label>
                {emailLoading ? (
                  <div className="w-full h-44 bg-slate-50 border border-slate-200 rounded-lg flex flex-col items-center justify-center text-xs text-slate-400 animate-pulse">
                    <span className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mb-2"></span>
                    Gemini is rewriting draft...
                  </div>
                ) : (
                  <textarea
                    value={activeDraft.body}
                    onChange={(e) => setActiveDraft({ ...activeDraft, body: e.target.value })}
                    className="w-full h-44 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium resize-none focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => handleCopyEmail(activeDraft.body, 99)}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  {copiedEmailIndex === 99 ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy Draft Content
                    </>
                  )}
                </button>
                <button
                  onClick={() => setShowEmailWorkspace(false)}
                  className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-xs transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* 3. GOAL BREAKDOWN MODAL INITIATION (If triggered directly from Sidebar/Quick Buttons) */}
      {showGoalModal && !goalResultSubtasks.length && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-base font-bold font-display text-slate-900 flex items-center gap-1.5">
                <Sparkles className="w-5 h-5 text-amber-500" />
                Break Down Goal with AI
              </h3>
              <button 
                onClick={() => setShowGoalModal(false)}
                className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleBreakDownGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Goal / Project Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Draft Q4 business scope"
                  value={goalForm.title}
                  onChange={(e) => setGoalForm({ ...goalForm, title: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Objectives & Requirements</label>
                <textarea
                  placeholder="e.g. Must include user journey maps, high level milestones, and feedback loop steps."
                  value={goalForm.description}
                  onChange={(e) => setGoalForm({ ...goalForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium h-20 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Target Hours Needed</label>
                <input
                  type="number"
                  value={goalForm.totalHours}
                  onChange={(e) => setGoalForm({ ...goalForm, totalHours: Number(e.target.value) })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowGoalModal(false)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-bold text-slate-600 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={breakingGoal}
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                >
                  {breakingGoal ? (
                    <>
                      <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Breaking Down...
                    </>
                  ) : (
                    "Generate Breakdown"
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

    </div>
  );
}
