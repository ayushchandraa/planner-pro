export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  urgency: 'high' | 'medium' | 'low';
  importance: 'high' | 'medium' | 'low';
  durationMinutes: number;
  dueDate: string; // YYYY-MM-DD
  completed: boolean;
  subtasks: SubTask[];
  dependencyId?: string; // ID of another task this depends on
}

export interface CalendarEvent {
  id: string;
  title: string;
  time: string; // "09:00 AM" or "14:30"
  duration: number; // in minutes
  description?: string;
}

export interface Habit {
  id: string;
  title: string;
  streak: number;
  completedToday: boolean;
  frequency: 'daily' | 'weekly';
}

export interface WorkSettings {
  focusStart: string; // e.g. "09:00"
  focusEnd: string; // e.g. "17:00"
  productivityPattern: 'morning' | 'afternoon' | 'evening';
}

export interface ScheduleSlot {
  time: string;
  type: 'task' | 'habit' | 'commitment' | 'rest';
  label: string;
  durationMinutes: number;
  taskId?: string;
}

export interface ScheduleAnalysis {
  riskScore: number;
  riskAnalysis: string;
  nextBestAction: string;
  recommendedSequence: string[];
  scheduleSlots: ScheduleSlot[];
  recommendations: string[];
}

export interface ExtensionEmail {
  subject: string;
  recipient: string;
  body: string;
  reason: string;
}

export interface RescuePlan {
  recoverySteps: string[];
  deferredTasks: string[]; // Task IDs recommended to defer
  extensionEmails: ExtensionEmail[];
  calmingQuote: string;
}
