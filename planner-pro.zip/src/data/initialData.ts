import { Task, CalendarEvent, Habit, WorkSettings } from "../types";

export const initialTasks: Task[] = [
  {
    id: "task-1",
    title: "Draft Q3 Financial Report & Projections",
    description: "Prepare the complete balance sheets, expense forecasts, and narrative for the leadership team review.",
    urgency: "high",
    importance: "high",
    durationMinutes: 120,
    dueDate: "2026-06-30", // Today
    completed: false,
    subtasks: [
      { id: "sub-1-1", title: "Consolidate June department expense worksheets", completed: true },
      { id: "sub-1-2", title: "Draft executive summary narrative", completed: false },
      { id: "sub-1-3", title: "Generate revenue projection models", completed: false }
    ]
  },
  {
    id: "task-2",
    title: "Review Design Specifications for Mobile App",
    description: "Check the UI/UX mockups for compliance with material guidelines and accessibility requirements.",
    urgency: "medium",
    importance: "high",
    durationMinutes: 90,
    dueDate: "2026-07-01", // Tomorrow
    completed: false,
    subtasks: [
      { id: "sub-2-1", title: "Review typography scale", completed: false },
      { id: "sub-2-2", title: "Validate color contrast ratios for dark theme", completed: false }
    ],
    dependencyId: "task-4" // Depends on client review
  },
  {
    id: "task-3",
    title: "Schedule Dentist Appointment",
    description: "Routine checkup and cleaning. Needs to be done before the insurance cycle resets.",
    urgency: "low",
    importance: "low",
    durationMinutes: 30,
    dueDate: "2026-07-05",
    completed: false,
    subtasks: []
  },
  {
    id: "task-4",
    title: "Collect Feedback from Client Mockup Review",
    description: "Get confirmation from Sarah regarding the updated home screen wireframes.",
    urgency: "high",
    importance: "medium",
    durationMinutes: 45,
    dueDate: "2026-06-30", // Today
    completed: true,
    subtasks: [
      { id: "sub-4-1", title: "Send email with prototype link", completed: true },
      { id: "sub-4-2", title: "Log specific feature requests", completed: true }
    ]
  },
  {
    id: "task-5",
    title: "Update Project Planner Pro Roadmap",
    description: "Re-align quarters based on client delayed launches.",
    urgency: "low",
    importance: "medium",
    durationMinutes: 60,
    dueDate: "2026-07-03",
    completed: false,
    subtasks: []
  }
];

export const initialCalendarEvents: CalendarEvent[] = [
  {
    id: "cal-1",
    title: "Weekly Sync: Product & Engineering",
    time: "10:00 AM",
    duration: 60,
    description: "Review milestones, blockages, and sprint velocities."
  },
  {
    id: "cal-2",
    title: "Sarah Client Wireframe Check-in",
    time: "01:30 PM",
    duration: 45,
    description: "Sarah reviews the design feedback and gives formal sign-off."
  },
  {
    id: "cal-3",
    title: "1-on-1 Mentorship with Dev Intern",
    time: "04:00 PM",
    duration: 30,
    description: "Discuss career progression and code review questions."
  }
];

export const initialHabits: Habit[] = [
  {
    id: "habit-1",
    title: "Morning Planning & Prioritization",
    streak: 8,
    completedToday: true,
    frequency: "daily"
  },
  {
    id: "habit-2",
    title: "Drink 3L of Water",
    streak: 3,
    completedToday: false,
    frequency: "daily"
  },
  {
    id: "habit-3",
    title: "30 Mins Coding Practice",
    streak: 14,
    completedToday: false,
    frequency: "daily"
  }
];

export const initialWorkSettings: WorkSettings = {
  focusStart: "09:00",
  focusEnd: "18:00",
  productivityPattern: "morning"
};
